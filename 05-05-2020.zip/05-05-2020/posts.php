<?php

require_once("dbManager.php");

class posts extends dbManager 
{
	function __construct()
	{
		parent::__construct();
	}
	function getAllPosts()
	{
		$sql = "SELECT * FROM posts";
		$result = $this->query($sql);
	}
}

$post = new posts();
$post->getAllPosts();
?>