<?php
//OOP
// class db
// {
// 	public $dbManager;
// 	function __construct()
// 	{
// 		require_once("dbConfig.php");

// 	}
// }

// class test
// {
// 	function __construct(){
// 		echo "auto calling...";
// 	}
// 	public $name;

// 	function printName()
// 	{
// 		echo $this->name;
// 	}

// 	function setName($value)
// 	{
// 		$this->name = $value;
// 		$this->printName();
// 	}

// 	function getName()
// 	{
// 		return $this->name;
// 	}
// }

// $test_object = new test();
// $test_object->setName("Ali");

?>