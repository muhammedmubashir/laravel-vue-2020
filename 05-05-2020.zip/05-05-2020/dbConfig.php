<?php
define("HOST","localhost");
define("USERNAME","root");
define("PASSWORD","123456");
define("DBNAME","blogs");
?>